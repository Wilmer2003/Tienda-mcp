"""
store_data.py
=============
Catálogo de productos e inventario inicial de la tienda.

Son datos simulados pero con variabilidad realista (precios, stock alto/bajo,
un producto agotado a propósito en 'P010') para poder demostrar los flujos
condicionales que pide el Criterio 4 de la rúbrica:
  - producto agotado -> el agente busca alternativas
  - stock bajo -> conflicto si dos pedidos compiten por la última unidad
"""

from server.models import Producto, Categoria

CATALOGO: list[Producto] = [
    Producto(id="P001", nombre="Laptop UltraBook 14",  categoria=Categoria.LAPTOPS,
             precio=3299.0, marca="Lenovo",  rating=4.6,
             descripcion="14'' Ryzen 7, 16GB RAM, 512GB SSD."),
    Producto(id="P002", nombre="Laptop Gamer 15",      categoria=Categoria.LAPTOPS,
             precio=4899.0, marca="Asus",    rating=4.7,
             descripcion="15.6'' RTX 4060, 16GB RAM, 1TB SSD."),
    Producto(id="P003", nombre="Smartphone Galaxy A55", categoria=Categoria.SMARTPHONES,
             precio=1499.0, marca="Samsung", rating=4.4,
             descripcion="6.6'' AMOLED, 128GB, cámara 50MP."),
    Producto(id="P004", nombre="Smartphone Pixel 8",    categoria=Categoria.SMARTPHONES,
             precio=2799.0, marca="Google",  rating=4.8,
             descripcion="6.2'' OLED, 128GB, IA de cámara."),
    Producto(id="P005", nombre="Audífonos WH-1000",     categoria=Categoria.AUDIO,
             precio=1199.0, marca="Sony",    rating=4.9,
             descripcion="Over-ear, cancelación de ruido, 30h batería."),
    Producto(id="P006", nombre="Audífonos AirBuds",     categoria=Categoria.AUDIO,
             precio=399.0,  marca="Anker",   rating=4.3,
             descripcion="In-ear inalámbricos, IPX5, estuche de carga."),
    Producto(id="P007", nombre="Tablet Tab S9",         categoria=Categoria.TABLETS,
             precio=2199.0, marca="Samsung", rating=4.5,
             descripcion="11'' 120Hz, 128GB, lápiz incluido."),
    Producto(id="P008", nombre="Mouse Inalámbrico MX",  categoria=Categoria.ACCESORIOS,
             precio=329.0,  marca="Logitech",rating=4.7,
             descripcion="Ergonómico, recargable, multi-dispositivo."),
    Producto(id="P009", nombre="Teclado Mecánico K65",  categoria=Categoria.ACCESORIOS,
             precio=459.0,  marca="Corsair", rating=4.6,
             descripcion="Switches rojos, RGB, formato compacto."),
    Producto(id="P010", nombre="Consola PlayBox X",     categoria=Categoria.GAMING,
             precio=2499.0, marca="GenX",    rating=4.8,
             descripcion="Consola 4K, 1TB, mando incluido."),  # agotada a propósito
    Producto(id="P011", nombre="Volante Racing Pro",    categoria=Categoria.GAMING,
             precio=899.0,  marca="GenX",    rating=4.2,
             descripcion="Volante con pedales y force feedback."),
    Producto(id="P012", nombre="Monitor 27 QHD",        categoria=Categoria.ACCESORIOS,
             precio=1099.0, marca="LG",      rating=4.6,
             descripcion="27'' IPS 165Hz, 1ms, HDR."),
]

# Inventario inicial: producto_id -> unidades disponibles
INVENTARIO_INICIAL: dict[str, int] = {
    "P001": 12, "P002": 4,  "P003": 25, "P004": 7,
    "P005": 15, "P006": 40, "P007": 9,  "P008": 50,
    "P009": 1,  # stock = 1: ideal para demostrar conflicto entre agentes
    "P010": 0,  # AGOTADO a propósito
    "P011": 6,  "P012": 10,
}
